CrystalRoyale resource pack starter (Java 1.21.11)

Contains a small custom bitmap font with three clock glyphs:
- U+E000: green clock
- U+E001: yellow clock
- U+E002: orange clock

This is a starter pack, not a complete Mindofneo HUD. The server/plugin must send the correct font component, phase title, subtitle, and timer. A resource pack cannot by itself position and update dynamic HUD elements.

Before publishing, verify pack_format against the exact Minecraft Java version and test in a clean client.
